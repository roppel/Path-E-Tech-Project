
//FirstView Component Constructor
//this is the first page with login screen
function FirstView(window) {
	//create object instance, a parasitic subclass of Observable
//	var window = Ti.UI.currentWindow();
	var self = Ti.UI.createView();
	var win = window;
	//label using localization-ready strings from <app dir>/i18n/en/strings.xml
	// var title = Ti.UI.createLabel({
		// color:'#000000',
		// text:String.format(L('m2Nexus Ratings Engine'),'m2Nexus Ratings Engine'),
		// top:50,
		// width:'auto'
	// });
	// self.add(title);
	
	var image = Ti.UI.createImageView({
  image:'/images/background.jpg',
  top:20,
  width:'70%',
  left:40
});
self.add(image);
	
	userID = Ti.UI.createTextField({
		top:140,
		width:200,
		left:50,
		borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
		hintText:"Username"
	});
	self.add(userID);
	
	jibeValue = Ti.UI.createTextField({
		top:180,
		width:200,
		left:50,
		borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
		hintText:"Jibe"
	});
	self.add(jibeValue);
	/*
	var password = Ti.UI.createTextField({
		top:160,
		width:200,
		left:50,
		borderStyle:Ti.UI.INPUT_BORDERSTYLE_ROUNDED,
		hintText:"Password",
		passwordMask:true
	});
	self.add(password);
	
	*/
	var button = Ti.UI.createButton({
		title: 'Login',
		top:220,
		left:50,
		width:80,
		height:30
		
	});
	self.add(button);
	//Add behavior for UI
	button.addEventListener('click', function(e) {
		if (userID.value == "") {
			alert('Please enter a user ID');
		}
		else {
			
			
			win.close();
    var introPage = require('ui/common/Content');
    
    /*
			var dialog = Ti.UI.createAlertDialog({
		
		
		title: 'Enter Jibe values:',
    style: Ti.UI.iPhone.AlertDialogStyle.PLAIN_TEXT_INPUT,
    buttonNames: ['OK']
		});
		dialog.addEventListener('click', function(e){
			jibeValue = Ti.UI.createTextField({
				value:e.text
			});
    Ti.API.info('e.text: ' + jibeValue.value);
    
  
  });
  dialog.show();
  */
	}
		
	});
	
//	Window = require('ui/tablet/IntroPage');
	
	//we love dilbert
	var image = Ti.UI.createImageView({
  image:'/images/dilbert.jpg',
  top:280,
  width:100
});
self.add(image);


	return self;
}

module.exports = FirstView;
