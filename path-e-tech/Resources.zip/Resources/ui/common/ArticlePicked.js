/**
 * @author Zack Roppel
 * 
 * when user picks something on Content page, this page opens up
 */

var win = Ti.UI.currentWindow;
var view = Ti.UI.createView();

var fivestar = Ti.UI.createImageView({
  image:'/images/5stars.png',
  top:80,
  left:15,
  width:'30%'
});
view.add(fivestar);

var fivestar = Ti.UI.createLabel({
		color:'#000000',
		text:': ' + win.fiveStarRatings,
		top:77,
		left:115
	});
	view.add(fivestar);

var fourstar = Ti.UI.createImageView({
  image:'/images/4stars.png',
  top:100,
  left:15,
  width:'30%'
});
view.add(fourstar);

var fourstar = Ti.UI.createLabel({
		color:'#000000',
		text:': ' + win.fourStarRatings,
		top:97,
		left:115
	});
	view.add(fourstar);

var threestar = Ti.UI.createImageView({
  image:'/images/3stars.png',
  top:120,
  left:15,
  width:'30%'
});
view.add(threestar);

var threestar = Ti.UI.createLabel({
		color:'#000000',
		text:': ' + win.threeStarRatings,
		top:117,
		left:115
	});
	view.add(threestar);

var twostar = Ti.UI.createImageView({
  image:'/images/2stars.png',
  top:140,
  left:15,
  width:'30%'
});
view.add(twostar);

var twostar = Ti.UI.createLabel({
		color:'#000000',
		text:': ' + win.twoStarRatings,
		top:137,
		left:115
	});
	view.add(twostar);

var onestar = Ti.UI.createImageView({
  image:'/images/1star.png',
  top:160,
  left:15,
  width:'30%'
});
view.add(onestar);

var onestar = Ti.UI.createLabel({
		color:'#000000',
		text:': ' + win.oneStarRatings,
		top:157,
		left:115
	});
	view.add(onestar);

var bookImage = Ti.UI.createImageView({
  image:win.bookImage,
  //height:150,
  top:10,
  right:15,
  bottom:'50%',
  width:'40%'
});
view.add(bookImage);

	var description = Ti.UI.createLabel({
		color:'#000000',
		text:win.topLeftText,
		top:10,
		width:'50%',
		left:15,
		textAlign:Ti.UI.TEXT_ALIGNMENT_LEFT
	});
	win.add(description);



var line = Ti.UI.createView({height:2,top:190,bottom:0,left:0,right:0,borderWidth:1,borderColor:'#000'});
view.add(line);

var RatingControl = require('ui/common/RatingControl');
var ratingControl = new RatingControl();

view.add(ratingControl);
 
 
    
    var submitButton = Titanium.UI.createButton({
	title:"Submit Rating",
	height:30,
	width:110,
	top:198,
	right:15
});  
 
view.add(submitButton);

//this is the window where the item review takes place

submitButton.addEventListener('click', function() {
  if (ratingControl.getValue() == 0) {
  	var alert = Titanium.UI.createAlertDialog({
  		title:"No Rating Selected",
  		message:"Please enter a value 1-5."})
  alert.show();
  }
  else {
  	var json;
  	var url = "http://108.166.89.121/Recommender.php?functionCall=LeaveRequest&uid="+ win.userID + "&iid=" + win.itemID + "&type=news&rate=" + ratingControl.getValue();

 var client = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
         Ti.API.info("Received text: " + this.responseText);
         json = JSON.parse(this.responseText);
         if (json.status == "error") {
         	var alert = Titanium.UI.createAlertDialog({
         		title:"Error",
         		message:"Your rating was not saved.",
         		buttonNames:["Ok"]
         		})
  alert.show();
         }
         else {
           var alert = Titanium.UI.createAlertDialog({
           	
  	
  	
    title:"Success: " + ratingControl.getValue(),
   
	
   message:"Would you like to leave a comment?",
   buttonNames: ["No","Yes"]
  })
  alert.show();
  
  alert.addEventListener("click",function(e){

	
	if(e.index == 0){
		//if no
		
	}else if(e.index == 1){
		//if yes
		
		var w = Ti.UI.createWindow({
				//title:'Title',//Take the title from the row
				backgroundColor:"#FFFFFF",
				tabBarHidden:true,
				urlPassed:url,
				rating:ratingControl.getValue(),
				title:win.getTitle(),
				url:'ItemReview.js'//The url property of a window will load an external .js file for window contents (be sure that external file is properly formatted!)
			});
			w.open();
		
	}
});
    } },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 client.open("GET", url);
 // Send the request.
 client.send();

}
});


	
var line = Ti.UI.createView({height:2,top:230,bottom:0,left:0,right:0,borderWidth:1,borderColor:'#000'});
view.add(line);

 //Method for custom table row creation for our content
//1. Store all the data we need in an array of objects
//2. Traverse the array in a for loop and make TableViewRows out of views
//3. Store the created TableViewRows in a new array
//4. Set the new array as the data source for our TableView

//1. Store all the data we need in an array of objects

//need to add using json and push onto array like this
//menu.push({id: 4, title: "this is the title" });
// var data = [ 
	// {review: 'I really liked this picture of a cat. It\'s hilarious!', author:'Steve Donnelly', rating:'5'}, 
	// {review: 'I don\'t really like cats, but this one is funny.', author:'Zack Roppel', rating:'4'}, 
	// {review: 'This is animal abuse. I am going to report you to PETA.', author:'Olga Tovashova', rating:'1'}, 
	// {review: 'Meow meow meow', author:'Nikolay Cherepanov', rating:'5'},
	// {review: 'If it\'s not Dilbert or Steve Jobs, it\'s bullshit.', author:'Bob Buckley', rating:'1'}
// 	
	// ]
	
	var data = win.itemReviews;
	var rowData = []; //An array that will hold our row objects created by createTableViewRow

//2. Traverse the array in a for loop and make TableViewRows out of views
for(var i = 0; i < data.length; i++){
	
	//Create rows to insert in the table row

	var review = Titanium.UI.createLabel({
		text:"Review: " + data[i].comment +
		"\nAuthor: " + data[i].userID
		 + "\nRating: " + data[i].ratingValue,//The title property of the data array
		height:'auto',
		width:'95%', //Ideally the screen width
		//bottom:0,
		//left:5,
		color:"#000",
		textAlign:"left"
	});
/*
	var author = Titanium.UI.createLabel({
		text:"Author: " + data[i].author,
		 + "\nRating: " + data[i].rating,
		 + //The amount property of the data array
		height:'auto',
		width:'auto', //Ideally the screen width
		//bottom:0,
		left:0,
		color:"#000",
		textAlign:"left"
	});
	
	var rating = Titanium.UI.createLabel({
		text:"Rating: " + data[i].rating,//The amount property of the data array
		height:'auto',
		width:'auto', //Ideally the screen width
		//bottom:0,
		left:0,
		color:"#000",
		textAlign:"left"
	});
	*/
	//Create the row
	var row = Titanium.UI.createTableViewRow({
		height:"auto",//Set the height of the row to auto so that it expands freely in the vertical direction
		touchEnabled: false
	});
	
	//Add the views to the row
	row.add(review);
	

	//3. Store the created TableViewRows in a new array
	//push the row into the array
	rowData.push(row);
}

//More complex table will use rows created with createTableViewRow
var tableView = Titanium.UI.createTableView({
	//4. Set the new array as the data source for our TableView
	data:rowData,
	top:232
});

view.add(tableView);


win.add(view);
