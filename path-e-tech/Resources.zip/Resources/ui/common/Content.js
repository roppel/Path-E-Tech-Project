
/**
 * @author Zack Roppel
 * 
 * this page loads after user has logged in
 */


Ti.UI.backgroundColor = 'white';
//create a tab group cause we want the title bar up top
tabGroup = Ti.UI.createTabGroup();

//the window will be the only thing in our tab group
var books = Ti.UI.createWindow({
	title:"Books"
});

var movies = Ti.UI.createWindow({
	title:"Movies"
});

var articles = Ti.UI.createWindow({
	title:"Articles"
});

var isJibe = false;
var isHot = false;

var moviesData = [];
var moviesDataHot = [];
var moviesDataJibe = [];
var moviesDataJibeHot = [];
var articlesData = [];
var articlesDataHot = [];
var articlesDataJibe = [];
var articlesDataJibeHot = [];
var booksData = [];
var booksDataHot = [];
var booksDataJibe = [];
var booksDataJibeHot = [];


tabGroup.addEventListener('open', function(){
    loadData();
});
books.addEventListener('focus', function(){
    loadData();
});

movies.addEventListener('focus', function(){
    loadData();
});

articles.addEventListener('focus', function(){
    loadData();
});

function loadData()
{
moviesData = [];
moviesDataHot = [];
moviesDataJibe = [];
moviesDataJibeHot = [];
articlesData = [];
articlesDataHot = [];
articlesDataJibe = [];
articlesDataJibeHot = [];
booksData = [];
booksDataHot = [];
booksDataJibe = [];
booksDataJibeHot = [];

//not hot or jibe movies

var json, movie, row, nameLabel;
 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequest&uid=" + userID.value + "&hotornot=1&type=movies";
 var movieClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	movie = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		userID:userID.value,
    			itemID:movie.movieID,
    			oneStarRatings:movie.One,
    			twoStarRatings:movie.Two,
    			threeStarRatings:movie.Three,
    			fourStarRatings:movie.Four,
    			fiveStarRatings:movie.Five,
    			itemReviews:movie.ratings,
    			genre:movie.genre,
    			height:'60'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:movie.movieTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'60',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		moviesData.push(row);
	     }
	     moviesTable.setData(moviesData);
     },
     
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     // timeout : 5000  // in milliseconds
     
 });
 // Prepare the connection.
 movieClient.open("GET", url);
 // Send the request.
 movieClient.send();
  
 //hot movies

var json, movie, row, nameLabel;
 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequest&uid=" + userID.value + "&hotornot=2&type=movies";
 var movieClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	movie = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		
    			userID:userID.value,
    			itemID:movie.movieID,
    			oneStarRatings:movie.One,
    			twoStarRatings:movie.Two,
    			threeStarRatings:movie.Three,
    			fourStarRatings:movie.Four,
    			fiveStarRatings:movie.Five,
    			itemReviews:movie.ratings,
    			genre:movie.genre,
    			height:'60'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:movie.movieTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'60',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		moviesDataHot.push(row);
	     }
	    // moviesTable.setData(moviesDataHot);
     },
     
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     // timeout : 5000  // in milliseconds
     
 });
 // Prepare the connection.
 movieClient.open("GET", url);
 // Send the request.
 movieClient.send();
 
 

 //not hot articles
var json, row, nameLabel, article;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequest&uid=" + userID.value + "&hotornot=1&type=news";
 var newsClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
         // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	article = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		userID:userID.value,
    			itemID:article.newsID,
    			newsAuthor:article.newsAuthor,
    			oneStarRatings:article.One,
    			twoStarRatings:article.Two,
    			threeStarRatings:article.Three,
    			fourStarRatings:article.Four,
    			fiveStarRatings:article.Five,
    			itemReviews:article.ratings,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:article.newsTitle,
            
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		articlesData.push(row);
	     }
	     articlesTable.setData(articlesData);
     },
     
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     // timeout : 5000  // in milliseconds
     
 });
 // Prepare the connection.
 newsClient.open("GET", url);
 // Send the request.
 newsClient.send();
 
 
 
	//hot articles
var json, row, nameLabel, article;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequest&uid=" + userID.value + "&hotornot=2&type=news";
 var newsClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	article = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		newsAuthor:article.newsAuthor,
         		userID:userID.value,
    			itemID:article.newsID,
    			oneStarRatings:article.One,
    			twoStarRatings:article.Two,
    			threeStarRatings:article.Three,
    			fourStarRatings:article.Four,
    			fiveStarRatings:article.Five,
    			itemReviews:article.ratings,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:article.newsTitle,
           
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		articlesDataHot.push(row);
	     }
	     //articlesTable.setData(articlesDataHot);
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     //timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 newsClient.open("GET", url);
 // Send the request.
 newsClient.send();


//set books data
var json, row, nameLabel, book;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequest&uid=" + userID.value + "&hotornot=1&type=books";
 var booksClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	book = json.data[i];

         	row = Ti.UI.createTableViewRow({
    			bookAuthor:book.BookAuthor,
    			bookImage:book.ImageUPLL,
    			itemReviews:book.ratings,
    			userID:userID.value,
    			itemID:book.bookID,
    			oneStarRatings:book.One,
    			twoStarRatings:book.Two,
    			threeStarRatings:book.Three,
    			fourStarRatings:book.Four,
    			fiveStarRatings:book.Five,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:book.BookTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		booksData.push(row);
	     }
	     booksTable.setData(booksData);
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     //timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 booksClient.open("GET", url);
 // Send the request.
 booksClient.send();
 

//this is the hot books
var json, row, nameLabel, book;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequest&uid=" + userID.value + "&hotornot=2&type=books";
 var booksClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	book = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		
    			
    			bookAuthor:book.BookAuthor,
    			bookImage:book.ImageUPLL,
    			itemReviews:book.ratings,
    			userID:userID.value,
    			itemID:book.bookID,
    			oneStarRatings:book.One,
    			twoStarRatings:book.Two,
    			threeStarRatings:book.Three,
    			fourStarRatings:book.Four,
    			fiveStarRatings:book.Five,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:book.BookTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		booksDataHot.push(row);
	     }
	    // booksTableHot.setData(booksDataHot);
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     //timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 booksClient.open("GET", url);
 // Send the request.
 booksClient.send();

//jibe movies

var json, movie, row, nameLabel;
 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequestJive&&uid=" + userID.value + "&hotornot=1&type=movies&fid=" + jibeValue.value;
 var movieClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
         //Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	movie = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		userID:userID.value,
    			itemID:movie.movieID,
    			oneStarRatings:movie.One,
    			twoStarRatings:movie.Two,
    			threeStarRatings:movie.Three,
    			fourStarRatings:movie.Four,
    			fiveStarRatings:movie.Five,
    			itemReviews:movie.ratings,
    			genre:movie.genre,
    			height:'60'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:movie.movieTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'60',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		moviesDataJibe.push(row);
  		
	     }
	   //  moviesTable.setData(moviesDataJibe);

     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
    // timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 movieClient.open("GET", url);
 // Send the request.
 

 movieClient.send();


 //hot and jibe movies

var json, movie, row, nameLabel;
 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequestJive&&uid=" + userID.value + "&hotornot=2&type=movies&fid=" + jibeValue.value;
 var movieClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	movie = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		userID:userID.value,
    			itemID:movie.movieID,
    			oneStarRatings:movie.One,
    			twoStarRatings:movie.Two,
    			threeStarRatings:movie.Three,
    			fourStarRatings:movie.Four,
    			fiveStarRatings:movie.Five,
    			itemReviews:movie.ratings,
    			genre:movie.genre,
    			height:'60'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:movie.movieTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'60',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		moviesDataJibeHot.push(row);
	     }
	    // moviesTable.setData(moviesDataHot);
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     //timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 movieClient.open("GET", url);
 // Send the request.
 movieClient.send();


 //jibe articles
var json, row, nameLabel, article;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequestJive&uid=" + userID.value + "&hotornot=1&type=news&fid=12";
 var newsClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	article = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		newsAuthor:article.newsAuthor,
         		userID:userID.value,
    			itemID:article.newsID,
    			oneStarRatings:article.One,
    			twoStarRatings:article.Two,
    			threeStarRatings:article.Three,
    			fourStarRatings:article.Four,
    			fiveStarRatings:article.Five,
    			itemReviews:article.ratings,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:article.newsTitle,
            
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		articlesDataJibe.push(row);
	     }
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     //timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 newsClient.open("GET", url);
 // Send the request.
 newsClient.send();
 
 
	//hot and jibe articles
var json, row, nameLabel, article;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequestJive&uid=" + userID.value + "&hotornot=2&type=news&fid=" + jibeValue.value;
 var newsClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	article = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		newsAuthor:article.newsAuthor,
    			userID:userID.value,
    			itemID:article.newsID,
    			oneStarRatings:article.One,
    			twoStarRatings:article.Two,
    			threeStarRatings:article.Three,
    			fourStarRatings:article.Four,
    			fiveStarRatings:article.Five,
    			itemReviews:article.ratings,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:article.newsTitle,
           
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		articlesDataJibeHot.push(row);
	     }
	     //articlesTable.setData(articlesDataHot);
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     // timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 newsClient.open("GET", url);
 // Send the request.
 newsClient.send();


 //books jibe data
var json, row, nameLabel, book;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequestJive&uid=" + userID.value + "&hotornot=1&type=books&fid=" + jibeValue.value;
 var booksClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	book = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		
    			bookAuthor:book.BookAuthor,
    			bookImage:book.ImageUPLL,
    			itemReviews:book.ratings,
    			userID:userID.value,
    			itemID:book.bookID,
    			oneStarRatings:book.One,
    			twoStarRatings:book.Two,
    			threeStarRatings:book.Three,
    			fourStarRatings:book.Four,
    			fiveStarRatings:book.Five,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:book.BookTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		booksDataJibe.push(row);
	     }
	    // booksTable.setData(booksData);
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     // timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 booksClient.open("GET", url);
 // Send the request.
 booksClient.send();




	//this is the hot books
var json, row, nameLabel, book;

 var url = "http://108.166.89.121/Recommender.php?functionCall=GetRequestJive&uid=" + userID.value + "&hotornot=2&type=books&fid=" + jibeValue.value;
 var booksClient = Ti.Network.createHTTPClient({
     // function called when the response data is available
     onload : function(e) {
        // Ti.API.info("Received text: " + this.responseText);
         //alert('success');
         json = JSON.parse(this.responseText);
         for (var i = 0; i < json.data.length; i++) {

         	book = json.data[i];

         	row = Ti.UI.createTableViewRow({
         		
    			bookAuthor:book.BookAuthor,
    			bookImage:book.ImageUPLL,
    			itemReviews:book.ratings,
    			userID:userID.value,
    			itemID:book.bookID,
    			oneStarRatings:book.One,
    			twoStarRatings:book.Two,
    			threeStarRatings:book.Three,
    			fourStarRatings:book.Four,
    			fiveStarRatings:book.Five,
    			height:'auto'
    		});
    		nameLabel = Ti.UI.createLabel({
            text:book.BookTitle,
            //textAlign:'left',
            font:{
                fontSize:'20',
            fontWeight:'bold'
        },
        
        height:'auto',
        top:'5',
        bottom:'5',
        width:'95%'
        });
       
        row.add(nameLabel);
        
  		booksDataJibeHot.push(row);
	     }
	    // booksTableHot.setData(booksDataHot);
     },
     // function called when an error occurs, including a timeout
     onerror : function(e) {
         Ti.API.debug(e.error);
         alert('error');
     },
     // timeout : 5000  // in milliseconds
 });
 // Prepare the connection.
 booksClient.open("GET", url);
 // Send the request.
 booksClient.send();

isJibe = false;
isHot = false;

};
//create tables
var booksTable = Ti.UI.createTableView({
  data: booksData
});

var articlesTable = Ti.UI.createTableView({
  data: articlesData
});

var moviesTable = Ti.UI.createTableView({
  data: moviesData
});

movies.add(moviesTable);
books.add(booksTable);
articles.add(articlesTable);


//actions when button is pressed
moviesTable.addEventListener("click", function(e){
	if (e.rowData.oneStarRatings == null) {
		e.rowData.oneStarRatings = "0";
	};
	if (e.rowData.twoStarRatings == null) {
		e.rowData.twoStarRatings = "0";
	};
	if (e.rowData.threeStarRatings == null) {
		e.rowData.threeStarRatings = "0";
	};
	if (e.rowData.fourStarRatings == null) {
		e.rowData.fourStarRatings = "0";
	};
	if (e.rowData.fiveStarRatings == null) {
		e.rowData.fiveStarRatings = "0";
	};
	//if (e.source.title == 'Cats') {
	var w = Ti.UI.createWindow({
	title:e.source.text,
	itemID:e.rowData.itemID,
	userID:e.rowData.userID,
	oneStarRatings:e.rowData.oneStarRatings,
	twoStarRatings:e.rowData.twoStarRatings,
	threeStarRatings:e.rowData.threeStarRatings,
	fourStarRatings:e.rowData.fourStarRatings,
	fiveStarRatings:e.rowData.fiveStarRatings,
	itemReviews:e.rowData.itemReviews,
	topLeftText:"Genre: " + e.rowData.genre,
	url:'/ui/common/MoviePicked.js'
	});


//opens the tab
moviesTab.open(w,{animated:true});
//}
});

booksTable.addEventListener("click", function(e){
	if (e.rowData.oneStarRatings == null) {
		e.rowData.oneStarRatings = "0";
	};
	if (e.rowData.twoStarRatings == null) {
		e.rowData.twoStarRatings = "0";
	};
	if (e.rowData.threeStarRatings == null) {
		e.rowData.threeStarRatings = "0";
	};
	if (e.rowData.fourStarRatings == null) {
		e.rowData.fourStarRatings = "0";
	};
	if (e.rowData.fiveStarRatings == null) {
		e.rowData.fiveStarRatings = "0";
	};
	//if (e.source.title == 'Cats') {
	var w = Ti.UI.createWindow({
	title:e.source.text,
	itemID:e.rowData.itemID,
	userID:e.rowData.userID,
	topLeftText:"Author: " + e.rowData.bookAuthor,
	bookImage:e.rowData.bookImage,
	oneStarRatings:e.rowData.oneStarRatings,
	twoStarRatings:e.rowData.twoStarRatings,
	threeStarRatings:e.rowData.threeStarRatings,
	fourStarRatings:e.rowData.fourStarRatings,
	fiveStarRatings:e.rowData.fiveStarRatings,
	itemReviews:e.rowData.itemReviews,
	url:'/ui/common/BookPicked.js',
	//theId:e.source.bookId
	});


//opens the tab
booksTab.open(w,{animated:true});
//}
});

articlesTable.addEventListener("click", function(e){
	if (e.rowData.oneStarRatings == null) {
		e.rowData.oneStarRatings = "0";
	};
	if (e.rowData.twoStarRatings == null) {
		e.rowData.twoStarRatings = "0";
	};
	if (e.rowData.threeStarRatings == null) {
		e.rowData.threeStarRatings = "0";
	};
	if (e.rowData.fourStarRatings == null) {
		e.rowData.fourStarRatings = "0";
	};
	if (e.rowData.fiveStarRatings == null) {
		e.rowData.fiveStarRatings = "0";
	};
	//if (e.source.title == 'Cats') {
	var w = Ti.UI.createWindow({
	title:e.source.text,
	itemID:e.rowData.itemID,
	userID:e.rowData.userID,
	topLeftText:"Source: " + e.rowData.newsAuthor,
	oneStarRatings:e.rowData.oneStarRatings,
	twoStarRatings:e.rowData.twoStarRatings,
	threeStarRatings:e.rowData.threeStarRatings,
	fourStarRatings:e.rowData.fourStarRatings,
	fiveStarRatings:e.rowData.fiveStarRatings,
	itemReviews:e.rowData.itemReviews,
	url:'/ui/common/ArticlePicked.js'
	});


//opens the tab
articlesTab.open(w,{animated:true});
//}
});




var moviesTab = Ti.UI.createTab({
	title:'Movies',
	icon: '/images/movies.png',
	window:movies
});

var booksTab = Ti.UI.createTab({
	title:'Books',
	icon: '/images/books.png',
	window:books
});

var articlesTab = Ti.UI.createTab({
	title:'News',
	icon: '/images/news.png',
	window:articles
});




//add jibe button to three tabs
var jibe = Ti.UI.createButton({
	title:"Jibe",
	//backgroundImage:"/images/jibe.png",
    style:Titanium.UI.iPhone.SystemButtonStyle.BORDERED
});
jibe.addEventListener("click", function() {
	
	//if not hot, only jibe on or off
	if (isHot == false) {
  if (isJibe == false) {
  	isJibe = true;
  	booksTable.setData(booksDataJibe);
  	moviesTable.setData(moviesDataJibe);
  	articlesTable.setData(articlesDataJibe);
  }
  else {
  	isJibe = false;
  	booksTable.setData(booksData);
  	moviesTable.setData(moviesData);
  	articlesTable.setData(articlesData);
  }
 }
 //if hot, have to consider that also
 else {
 if (isJibe == false) {
  	isJibe = true;
  	booksTable.setData(booksDataJibeHot);
  	moviesTable.setData(moviesDataJibeHot);
  	articlesTable.setData(articlesDataJibeHot);
  }
  else {
  	isJibe = false;
  	booksTable.setData(booksDataHot);
  	moviesTable.setData(moviesDataHot);
  	articlesTable.setData(articlesDataHot);
  }
 }
});
books.setLeftNavButton(jibe);
movies.setLeftNavButton(jibe);
articles.setLeftNavButton(jibe);


//add hot button
var hot = Ti.UI.createButton({
	title:"Hot"
    //style:Titanium.UI.iPhone.SystemButtonStyle.BORDERED
});
hot.addEventListener("click", function() {
	//if not jibe, only hot
	if (isJibe == false) {
  if (isHot == false) {
  	
  	isHot = true;
  	booksTable.setData(booksDataHot);
  	moviesTable.setData(moviesDataHot);
  	articlesTable.setData(articlesDataHot);
  }
  else {
  	isHot = false;
  	booksTable.setData(booksData);
  	moviesTable.setData(moviesData);
  	articlesTable.setData(articlesData);
  }
 }
 //jibe is on
 else {
 	if (isHot == false) {
  	
  	isHot = true;
  	booksTable.setData(booksDataJibeHot);
  	moviesTable.setData(moviesDataJibeHot);
  	articlesTable.setData(articlesDataJibeHot);
  }
  else {
  	isHot = false;
  	booksTable.setData(booksDataJibe);
  	moviesTable.setData(moviesDataJibe);
  	articlesTable.setData(articlesDataJibe);
  }
 }
});
books.setRightNavButton(hot);
movies.setRightNavButton(hot);
articles.setRightNavButton(hot);

tabGroup.addTab(moviesTab);
tabGroup.addTab(booksTab);
tabGroup.addTab(articlesTab);

tabGroup.open();


